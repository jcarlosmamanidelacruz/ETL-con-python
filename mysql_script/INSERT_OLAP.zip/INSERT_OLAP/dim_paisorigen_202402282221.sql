INSERT INTO importaciones_olap.dim_paisorigen (IdPaisOrigen,NombrePaisOrigen) VALUES
	 (1,'ESTADOS UNIDOS'),
	 (2,'JAPON'),
	 (3,'CANADA'),
	 (4,'ALEMANIA REP. FED.'),
	 (5,'SLOVAKIA'),
	 (6,'ESPANA'),
	 (7,'INDIA'),
	 (8,'CHINA'),
	 (9,'MEXICO'),
	 (10,'COREA DEL SUR');
INSERT INTO importaciones_olap.dim_paisorigen (IdPaisOrigen,NombrePaisOrigen) VALUES
	 (11,'KOREA DEL NORTE (REPUBLICA DEMOCRATICA)'),
	 (12,'FRANCIA'),
	 (13,'ITALIA'),
	 (14,'TURQUIA'),
	 (15,'TAIWAN'),
	 (16,'REINO UNIDO'),
	 (17,'BRASIL'),
	 (18,'TAILANDIA'),
	 (19,'SUECIA'),
	 (20,'BELICE');
INSERT INTO importaciones_olap.dim_paisorigen (IdPaisOrigen,NombrePaisOrigen) VALUES
	 (21,'AUSTRIA'),
	 (22,'COLOMBIA'),
	 (23,'INDONESIA'),
	 (24,'ARGENTINA'),
	 (25,'BELGICA'),
	 (26,'BELARUS'),
	 (27,'SUIZA');
