INSERT INTO importaciones_olap.dim_fecha (IdFecha,FechaImportacion,Anio,Mes,Mes_nombre) VALUES
	 (20170102,'2017-01-02',2017,1,'January'),
	 (20170113,'2017-01-13',2017,1,'January'),
	 (20170114,'2017-01-14',2017,1,'January'),
	 (20170115,'2017-01-15',2017,1,'January'),
	 (20170116,'2017-01-16',2017,1,'January'),
	 (20170117,'2017-01-17',2017,1,'January'),
	 (20170118,'2017-01-18',2017,1,'January'),
	 (20170119,'2017-01-19',2017,1,'January'),
	 (20170120,'2017-01-20',2017,1,'January'),
	 (20170121,'2017-01-21',2017,1,'January');
INSERT INTO importaciones_olap.dim_fecha (IdFecha,FechaImportacion,Anio,Mes,Mes_nombre) VALUES
	 (20170122,'2017-01-22',2017,1,'January'),
	 (20170123,'2017-01-23',2017,1,'January'),
	 (20170124,'2017-01-24',2017,1,'January'),
	 (20170125,'2017-01-25',2017,1,'January'),
	 (20170126,'2017-01-26',2017,1,'January'),
	 (20170127,'2017-01-27',2017,1,'January'),
	 (20170128,'2017-01-28',2017,1,'January'),
	 (20170129,'2017-01-29',2017,1,'January'),
	 (20170130,'2017-01-30',2017,1,'January'),
	 (20170131,'2017-01-31',2017,1,'January');
INSERT INTO importaciones_olap.dim_fecha (IdFecha,FechaImportacion,Anio,Mes,Mes_nombre) VALUES
	 (20170202,'2017-02-02',2017,2,'February'),
	 (20170302,'2017-03-02',2017,3,'March'),
	 (20170402,'2017-04-02',2017,4,'April'),
	 (20170502,'2017-05-02',2017,5,'May'),
	 (20170602,'2017-06-02',2017,6,'June'),
	 (20170702,'2017-07-02',2017,7,'July'),
	 (20170801,'2017-08-01',2017,8,'August'),
	 (20170901,'2017-09-01',2017,9,'September'),
	 (20171001,'2017-10-01',2017,10,'October'),
	 (20171101,'2017-11-01',2017,11,'November');
INSERT INTO importaciones_olap.dim_fecha (IdFecha,FechaImportacion,Anio,Mes,Mes_nombre) VALUES
	 (20171201,'2017-12-01',2017,12,'December');
