INSERT INTO importaciones_olap.dim_aduanaingreso (IdAduanaIngreso,NombreAduanaIngreso) VALUES
	 (1,'PUERTO BARRIOS'),
	 (2,'SANTO TOMAS DE CASTILLA'),
	 (3,'EL CARMEN'),
	 (4,'G8, CENTRALSA'),
	 (5,'TECUN UMAN'),
	 (6,'G1, INTEGRADA'),
	 (7,'G4, ALSERSA'),
	 (8,'EXPRESS AEREO'),
	 (9,'PUERTO QUETZAL'),
	 (10,'PEDRO DE ALVARADO');
INSERT INTO importaciones_olap.dim_aduanaingreso (IdAduanaIngreso,NombreAduanaIngreso) VALUES
	 (11,'VALLE NUEVO'),
	 (12,'MELCHOR DE MENCOS'),
	 (13,'EL CEIBO'),
	 (14,'SAN CRISTOBAL'),
	 (15,'AGUA CALIENTE'),
	 (16,'LA MESILLA'),
	 (17,'G5, CEALSA');
